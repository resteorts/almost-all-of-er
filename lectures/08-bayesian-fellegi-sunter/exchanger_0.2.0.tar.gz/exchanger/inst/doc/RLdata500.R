## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=7, 
  fig.height=5
)
set.seed(319158)

## ---- eval=TRUE, message=FALSE, warning=FALSE---------------------------------
library(exchanger)
library(comparator)
library(clevr)
head(RLdata500)

## ---- eval=TRUE, message=FALSE, warning=FALSE---------------------------------
unif_prior <- BetaRV(1, 1)

## ---- eval=TRUE, message=FALSE------------------------------------------------
attr_params <- list(
  "fname_c1" = Attribute(transform_dist_fn(Levenshtein(), threshold = 3.0),
                         distort_prob_prior = unif_prior),
  "lname_c1" = Attribute(transform_dist_fn(Levenshtein(), threshold = 3.0),
                         distort_prob_prior = unif_prior),
  "by" = CategoricalAttribute(distort_prob_prior = unif_prior),
  "bm" = CategoricalAttribute(distort_prob_prior = unif_prior),
  "bd" = CategoricalAttribute(distort_prob_prior = unif_prior)
)

## ---- eval=TRUE, message=FALSE------------------------------------------------
clust_prior <- PitmanYorRP(alpha = GammaRV(1, 1), d = BetaRV(1, 1))

## ---- eval=TRUE, message=FALSE------------------------------------------------
model <- exchanger(RLdata500, attr_params, clust_prior)
system.time(
result <- run_inference(model, n_samples=100, thin_interval=10, burnin_interval=1000)
)

## ---- eval=TRUE---------------------------------------------------------------
pred_clusters <- smp_clusters(result)

## ---- eval=TRUE---------------------------------------------------------------
n_records <- nrow(RLdata500)
true_pairs <- membership_to_pairs(identity.RLdata500)
pred_pairs <- clusters_to_pairs(pred_clusters)
measures <- eval_report_pairs(true_pairs, pred_pairs, num_pairs=n_records*(n_records-1)/2)
print(measures)

## -----------------------------------------------------------------------------
plot(result@history$n_linked_ents, type = "l", xlab="Iteration", ylab="Num. linked entities")
matplot(result@history$n_distorted_per_attr / n_records * 100, type="l", xlab="Iteration", ylab="% distorted")

